export interface BreadcrumbItem {
  label: string;
  url?: string;
}