#!/bin/bash

# Build Angular cho production
echo "Building Angular for production..."
ng build --configuration=production

# Copy files to production server
echo "Copying files to production server..."
# Thay đổi đường dẫn này thành server thật của bạn
# scp -r dist/exe201-fe/* user@your-server:/var/www/html/

echo "Production build completed!"
echo "Remember to:"
echo "1. Update VNPay production credentials"
echo "2. Update database connection"
echo "3. Update domain URLs"
echo "4. Enable HTTPS"
echo "5. Configure firewall and security"
