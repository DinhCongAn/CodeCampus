
import { UriConfig } from "./uriConfig";


export class RequestUri {
    //Tên api để kết nối
    static F_LIST_PRODUCT = UriConfig.Products + '/all';
    static F_PRODUCT = UriConfig.Products + '/';
    static F_LIST_CATEGORY = UriConfig.Products + '/types';
}
