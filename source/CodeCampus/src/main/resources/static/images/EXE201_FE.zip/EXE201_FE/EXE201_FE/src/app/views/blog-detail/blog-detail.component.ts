import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

interface BlogPost {
  id: string;
  title: string;
  category: string;
  categoryColor: string;
  date: string;
  image: string;
  breadcrumb: string;
  content: string;
  tags: string[];
}

@Component({
  selector: 'app-blog-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="min-h-screen bg-gray-50" *ngIf="currentBlog">
      <!-- Header -->
      <div class="bg-white shadow-sm">
        <div class="max-w-4xl mx-auto px-4 py-8">
          <div class="flex items-center space-x-4 mb-6">
            <button (click)="goBack()" class="text-gray-600 hover:text-gray-800">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
              </svg>
            </button>
            <span class="text-sm text-gray-500">Blog / {{ currentBlog.breadcrumb }}</span>
          </div>
          
          <div class="text-center">
            <h1 class="text-4xl font-bold text-gray-900 mb-4">{{ currentBlog.title }}</h1>
            <div class="flex items-center justify-center space-x-4 text-gray-600">
              <span class="flex items-center">
                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path>
                </svg>
                Admin
              </span>
              <span class="flex items-center">
                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                </svg>
                {{ currentBlog.date }}
              </span>
              <span [ngClass]="{
                'bg-red-600': currentBlog.categoryColor === 'red',
                'bg-amber-600': currentBlog.categoryColor === 'amber',
                'bg-green-600': currentBlog.categoryColor === 'green'
              }" class="text-white px-3 py-1 rounded-full text-sm font-medium">
                {{ currentBlog.category }}
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content -->
      <div class="max-w-4xl mx-auto px-4 py-8">
        <article class="bg-white rounded-lg shadow-lg overflow-hidden">
          <!-- Featured Image -->
          <div class="relative">
            <img [src]="currentBlog.image" 
                 [alt]="currentBlog.title" 
                 class="w-full h-96 object-cover">
          </div>

          <!-- Article Content -->
          <div class="p-8">
            <div class="prose prose-lg max-w-none" [innerHTML]="currentBlog.content"></div>

            <!-- Tags -->
            <div class="border-t pt-6 mt-8">
              <h3 class="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
              <div class="flex flex-wrap gap-2">
                <span *ngFor="let tag of currentBlog.tags" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">{{ tag }}</span>
              </div>
            </div>
          </div>
        </article>

        <!-- Related Articles -->
        <div class="mt-12">
          <h3 class="text-2xl font-bold text-gray-900 mb-6">Bài viết liên quan</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <article *ngFor="let related of relatedBlogs" 
                     class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                     (click)="navigateToBlog(related.id)">
              <img [src]="related.image" 
                   [alt]="related.title" 
                   class="w-full h-48 object-cover">
              <div class="p-4">
                <h4 class="font-semibold text-gray-900 mb-2">{{ related.title }}</h4>
                <p class="text-gray-600 text-sm">{{ related.category }}</p>
              </div>
            </article>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class BlogDetailComponent implements OnInit {
  currentBlog: BlogPost | null = null;
  relatedBlogs: BlogPost[] = [];

  private blogPosts: BlogPost[] = [
    {
      id: 'son-mai-truyen-thong',
      title: 'Tranh sơn mài làng Hạ Thái - Hồn quê trong từng nét vẽ',
      category: 'Quê hương',
      categoryColor: 'red',
      date: '15 tháng 12, 2024',
      image: 'https://res.cloudinary.com/doez63ydh/image/upload/v1760539378/anh_blog_gj8fp3.jpg',
      breadcrumb: 'Tranh sơn mài Hạ Thái',
      content: `
        <p class="text-xl text-gray-700 leading-relaxed mb-6">
          Làng Hạ Thái, thuộc xã Duyên Thái, huyện Thường Tín, Hà Nội, là một trong những cái nôi 
          của nghề sơn mài truyền thống Việt Nam. Với hơn 400 năm lịch sử, làng Hạ Thái đã tạo ra 
          những tác phẩm sơn mài mang đậm hồn quê, phản ánh cuộc sống bình dị của người dân Việt Nam.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Lịch sử làng nghề Hạ Thái</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Làng Hạ Thái được hình thành từ thế kỷ 16, khi những người thợ sơn mài từ các vùng khác 
          đến định cư và truyền nghề. Qua nhiều thế hệ, làng đã phát triển thành một trung tâm 
          sơn mài nổi tiếng với những tác phẩm mang đậm bản sắc văn hóa địa phương.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Đặc trưng nghệ thuật</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Tranh sơn mài Hạ Thái nổi tiếng với những chủ đề gần gũi với đời sống nông thôn: 
          cảnh đồng quê, làng xóm, cây đa, bến nước, con đò, hay những hình ảnh sinh hoạt 
          hàng ngày của người dân. Mỗi tác phẩm đều thấm đẫm tình yêu quê hương, đất nước.
        </p>

        <div class="bg-amber-50 border-l-4 border-amber-400 p-6 my-8">
          <h3 class="text-lg font-semibold text-amber-800 mb-2">Hồn quê trong từng nét vẽ</h3>
          <p class="text-amber-700">
            Các nghệ nhân Hạ Thái không chỉ tạo ra những tác phẩm đẹp mắt, mà còn gửi gắm 
            tình cảm sâu sắc về quê hương, về những kỷ niệm tuổi thơ, về cuộc sống bình dị 
            nơi làng quê Việt Nam.
          </p>
        </div>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Kỹ thuật đặc biệt</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Nghệ nhân Hạ Thái sử dụng kỹ thuật sơn mài truyền thống kết hợp với khảm trai, 
          tạo ra những hiệu ứng ánh sáng đa chiều. Đặc biệt, họ thường sử dụng màu sắc 
          ấm áp, gần gũi như màu vàng của lúa chín, màu xanh của lá cây, màu đỏ của hoa gạo.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Chủ đề phổ biến</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Tranh sơn mài Hạ Thái thường tập trung vào những chủ đề:
        </p>
        
        <ul class="list-disc list-inside text-gray-700 mb-6 space-y-2">
          <li><strong>Cảnh làng quê:</strong> Đồng lúa, cây đa, bến nước, con đò</li>
          <li><strong>Sinh hoạt dân gian:</strong> Hội làng, đám cưới, lễ hội truyền thống</li>
          <li><strong>Phong cảnh thiên nhiên:</strong> Sông nước, núi non, cây cối</li>
          <li><strong>Động vật quen thuộc:</strong> Trâu, bò, gà, vịt, chim chóc</li>
          <li><strong>Con người:</strong> Người nông dân, trẻ em, phụ nữ làng quê</li>
        </ul>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Giá trị văn hóa</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Tranh sơn mài Hạ Thái không chỉ là tác phẩm nghệ thuật, mà còn là cầu nối 
          giữa quá khứ và hiện tại, giữa truyền thống và hiện đại. Mỗi bức tranh đều 
          kể một câu chuyện về cuộc sống, về con người, về tình yêu quê hương đất nước.
        </p>

        <p class="text-gray-700 leading-relaxed mb-8">
          Ngày nay, tranh sơn mài Hạ Thái vẫn được nhiều người yêu thích và tìm mua. 
          Không chỉ là món quà lưu niệm, những tác phẩm này còn là cách để mỗi người 
          giữ gìn và truyền lại tình yêu quê hương cho thế hệ sau.
        </p>
      `,
      tags: ['Hạ Thái', 'Làng nghề', 'Quê hương', 'Tranh sơn mài', 'Văn hóa']
    },
    {
      id: 'bo-suu-tap-tranh-son-mai-ha-thai',
      title: 'Bộ sưu tập tranh sơn mài Hạ Thái - Tinh hoa nghệ thuật truyền thống',
      category: 'Bộ sưu tập',
      categoryColor: 'amber',
      date: '20 tháng 12, 2024',
      image: 'https://res.cloudinary.com/dn2yksaoq/image/upload/v1762448836/574573114_811366424846220_6501767726054286666_n_lqcoln.png',
      breadcrumb: 'Bộ sưu tập tranh sơn mài',
      content: `
        <p class="text-xl text-gray-700 leading-relaxed mb-6">
          Bộ sưu tập tranh sơn mài Hạ Thái là một tuyển tập độc đáo những tác phẩm nghệ thuật 
          mang đậm hơi thở cuộc sống đời thường, phố cổ và văn hóa Việt Nam. Mỗi bức tranh trong 
          bộ sưu tập này đều được chế tác thủ công bởi các nghệ nhân làng nghề Hạ Thái với kỹ thuật 
          truyền thống được truyền qua nhiều thế hệ.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Giới thiệu bộ sưu tập</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Bộ sưu tập bao gồm những tác phẩm sơn mài với kích thước 15×15 cm, mỗi bức tranh kể một 
          câu chuyện riêng về cuộc sống, con người và văn hóa Việt Nam. Từ những hình ảnh quen thuộc 
          của phố cổ Hà Nội đến những khoảnh khắc bình dị trong đời sống hàng ngày, mỗi tác phẩm đều 
          mang trong mình một giá trị nghệ thuật và văn hóa sâu sắc.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Các tác phẩm nổi bật</h2>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Tranh sơn mài "Phố Mùa Đông" – 15×15 cm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Tác phẩm khắc họa hình ảnh người đàn ông đội nón lá, mặc áo xanh, đạp chiếc xích lô màu nâu 
          đi giữa con đường vắng. Trên nền là những mái nhà ngói đỏ đậm xen lẫn bức tường vàng xỉn – 
          gam màu đặc trưng của phố cũ Hà Nội.
        </p>
        <p class="text-gray-700 leading-relaxed mb-4">
          Nổi bật trong bức tranh là thân cây trơ cành ở góc trái, gợi cảm giác mùa đông hoặc cuối thu, 
          khi cảnh vật trở nên trầm lặng và hoài niệm. Gam màu tổng thể ấm – trầm – nhẹ, kết hợp với đường 
          viền đen mảnh khiến bố cục cân đối, mang nét đẹp bình dị nhưng sâu lắng.
        </p>
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 my-4">
          <p class="text-blue-800 text-sm"><strong>Thông tin sản phẩm:</strong></p>
          <ul class="text-blue-700 text-sm list-disc list-inside mt-2">
            <li>Kích thước: 15 × 15 cm</li>
            <li>Chất liệu: Sơn mài thủ công truyền thống – làng nghề Hạ Thái, Thường Tín, Hà Nội</li>
            <li>Màu sắc chủ đạo: Nâu đất, đỏ ngói, vàng khói</li>
            <li>Phong cách: Hoài cổ – tĩnh tại – đậm chất Việt</li>
          </ul>
        </div>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Tranh sơn mài "Người Gánh Quê" – 15×15 cm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Tác phẩm thể hiện hình ảnh người phụ nữ lao động – biểu tượng của sự tần tảo và bền bỉ trong 
          đời sống Việt Nam. Phông nền vàng ấm tượng trưng cho ánh nắng buổi sớm, trong khi mái ngói đỏ 
          và cửa sổ xanh gợi nên khung cảnh yên bình của vùng quê Bắc Bộ.
        </p>
        <p class="text-gray-700 leading-relaxed mb-4">
          Các đường nét đen được vẽ tối giản nhưng vẫn giữ được cảm giác chuyển động tự nhiên của bước chân 
          và nhịp gánh. Bức tranh phù hợp để trưng bày trong không gian mộc mạc, mang đậm hơi thở Việt.
        </p>
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 my-4">
          <p class="text-blue-800 text-sm"><strong>Thông tin sản phẩm:</strong></p>
          <ul class="text-blue-700 text-sm list-disc list-inside mt-2">
            <li>Kích thước: 15 × 15 cm</li>
            <li>Chất liệu: Sơn mài truyền thống, thủ công tại làng nghề Hạ Thái – Thường Tín, Hà Nội</li>
            <li>Màu sắc chủ đạo: Vàng nhũ, xanh lá, nâu đất</li>
            <li>Phong cách: Tối giản – dân dã – gần gũi</li>
          </ul>
        </div>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Tranh sơn mài "Hành Trình Bình Dị" – 15×15 cm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Bức tranh tái hiện hình ảnh quen thuộc người phụ nữ đội nón lá mặc áo xanh lá, đạp xe chở con nhỏ 
          phía sau. Trên lề đường, một người phụ nữ khác mặc áo hồng đang thong thả đi bộ.
        </p>
        <p class="text-gray-700 leading-relaxed mb-4">
          Phía sau là dãy nhà mái ngói đỏ vàng với hình khối mộc mạc đặc trưng, gợi cảm giác phố cổ Bắc Bộ 
          trong một buổi sáng nhẹ. Gam màu vàng be, đỏ ngói, xám nhạt được phối tinh tế, tạo hiệu ứng mềm mại 
          và tự nhiên. Tác phẩm mang hơi thở của nhịp sống chậm rãi, thân thiện, khơi gợi ký ức tuổi thơ 
          và tình cảm gia đình giản dị.
        </p>
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 my-4">
          <p class="text-blue-800 text-sm"><strong>Thông tin sản phẩm:</strong></p>
          <ul class="text-blue-700 text-sm list-disc list-inside mt-2">
            <li>Kích thước: 15 × 15 cm</li>
            <li>Chất liệu: Sơn mài thủ công truyền thống – làng nghề Hạ Thái, Thường Tín, Hà Nội</li>
            <li>Màu sắc chủ đạo: Be vàng, đỏ ngói, xanh lá, hồng phấn</li>
            <li>Phong cách: Hoài cổ – dân dã – ấm áp</li>
          </ul>
        </div>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Tranh sơn mài "Nắng Trên Phố Cổ" – 15×15 cm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Tác phẩm nổi bật với phông nền vàng ánh kim rực rỡ như mặt trời buổi sớm. Những ngôi nhà mái ngói 
          đỏ nâu, tường trắng loang vàng, cùng đường cong mềm dẫn mắt người xem vào chiều sâu không gian.
        </p>
        <p class="text-gray-700 leading-relaxed mb-4">
          Điểm nhấn của bức tranh là hai dáng người nhỏ – mẹ và con đang cùng nhau đi giữa phố, gợi cảm giác 
          ấm áp, gắn bó gia đình và nét hồn hậu của người Việt. Gam màu chủ đạo vàng – đỏ – nâu đất hòa quyện 
          tinh tế, thể hiện rõ kỹ thuật sơn mài truyền thống trong cách phối sáng và xử lý bề mặt.
        </p>
        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 my-4">
          <p class="text-blue-800 text-sm"><strong>Thông tin sản phẩm:</strong></p>
          <ul class="text-blue-700 text-sm list-disc list-inside mt-2">
            <li>Kích thước: 15 × 15 cm</li>
            <li>Chất liệu: Sơn mài thủ công – chế tác tại làng nghề Hạ Thái, Thường Tín, Hà Nội</li>
            <li>Màu sắc chủ đạo: Vàng ánh kim, đỏ ngói, nâu đất</li>
            <li>Phong cách: Tươi sáng – hoài cổ – mang hơi thở đời thường</li>
          </ul>
        </div>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Tranh sơn mài "Chuyện Bên Đường" – 15×15 cm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Tác phẩm tái hiện lại nét sinh hoạt bình dị của người dân phố cổ, khắc họa những khoảnh khắc 
          đời thường đầy cảm xúc và gần gũi.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Bảo hành & đóng gói</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Tất cả các tác phẩm trong bộ sưu tập đều được bảo hành lớp sơn 6 tháng và được đóng gói cẩn thận 
          trong hộp kraft in logo Sơn Mài Heritage, đảm bảo an toàn trong quá trình vận chuyển.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Giá trị nghệ thuật</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Bộ sưu tập tranh sơn mài Hạ Thái không chỉ là những tác phẩm nghệ thuật trang trí, mà còn là 
          cầu nối giữa quá khứ và hiện tại, giữa truyền thống và hiện đại. Mỗi bức tranh đều mang trong mình 
          một câu chuyện về cuộc sống, về con người, về tình yêu quê hương đất nước.
        </p>

        <p class="text-gray-700 leading-relaxed mb-8">
          Những tác phẩm này phù hợp để trưng bày trong không gian yên tĩnh, thư giãn như phòng đọc, homestay 
          hoặc quán cà phê phong cách hoài cổ, mang lại cảm giác ấm áp và gần gũi cho không gian sống.
        </p>
      `,
      tags: ['Bộ sưu tập', 'Hạ Thái', 'Tranh sơn mài', 'Nghệ thuật', 'Truyền thống']
    },
    {
      id: 'workshop-trai-nghiem-son-mai-ha-thai',
      title: 'Workshop trải nghiệm làm đồ sơn mài tại làng nghề Hạ Thái',
      category: 'Trải nghiệm',
      categoryColor: 'green',
      date: '25 tháng 12, 2024',
      image: 'https://res.cloudinary.com/dn2yksaoq/image/upload/v1762448159/575958290_1338028154730592_6574423710949499814_n_swr8gn.png',
      breadcrumb: 'Workshop trải nghiệm',
      content: `
        <p class="text-xl text-gray-700 leading-relaxed mb-6">
          Trải nghiệm thực tế quy trình làm sơn mài truyền thống tại làng nghề Hạ Thái là cơ hội tuyệt vời 
          để bạn được hòa mình vào không gian văn hóa đậm đà bản sắc Việt Nam, học hỏi từ các nghệ nhân 
          và tự tay tạo ra những tác phẩm sơn mài của riêng mình.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Giới thiệu về Workshop</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Workshop trải nghiệm làm đồ sơn mài tại làng nghề Hạ Thái được thiết kế để mang đến cho bạn 
          một hành trình khám phá đầy thú vị về nghề sơn mài truyền thống. Tại đây, bạn sẽ được các nghệ nhân 
          giàu kinh nghiệm hướng dẫn từng bước trong quy trình chế tác sơn mài, từ việc chuẩn bị nguyên liệu 
          đến hoàn thiện tác phẩm.
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Quy trình trải nghiệm</h2>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Bước 1: Tham quan làng nghề</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Bắt đầu hành trình với việc tham quan làng nghề Hạ Thái, tìm hiểu về lịch sử hơn 400 năm của 
          làng nghề, chiêm ngưỡng các tác phẩm sơn mài truyền thống và hiện đại được trưng bày tại các 
          xưởng sản xuất.
        </p>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Bước 2: Tìm hiểu về nguyên liệu</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Bạn sẽ được giới thiệu về các loại nguyên liệu truyền thống được sử dụng trong nghề sơn mài: 
          sơn ta, vàng bạc, vỏ trứng, vỏ trai, và các loại màu tự nhiên. Nghệ nhân sẽ giải thích về 
          đặc tính và cách sử dụng từng loại nguyên liệu.
        </p>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Bước 3: Thực hành kỹ thuật cơ bản</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Dưới sự hướng dẫn của nghệ nhân, bạn sẽ học các kỹ thuật cơ bản như:
        </p>
        <ul class="list-disc list-inside text-gray-700 mb-6 space-y-2">
          <li><strong>Quét sơn lót:</strong> Kỹ thuật quét lớp sơn đầu tiên lên bề mặt gỗ</li>
          <li><strong>Vẽ phác thảo:</strong> Sử dụng bút vẽ để tạo hình ảnh trên nền sơn</li>
          <li><strong>Khảm trai/vỏ trứng:</strong> Kỹ thuật khảm các vật liệu tự nhiên vào tác phẩm</li>
          <li><strong>Mài và đánh bóng:</strong> Quy trình mài và đánh bóng để tạo độ bóng và độ sâu cho tác phẩm</li>
        </ul>

        <h3 class="text-xl font-semibold text-gray-900 mt-6 mb-3">Bước 4: Tự tay tạo tác phẩm</h3>
        <p class="text-gray-700 leading-relaxed mb-4">
          Sau khi nắm vững các kỹ thuật cơ bản, bạn sẽ được tự tay tạo ra một tác phẩm sơn mài của riêng mình. 
          Nghệ nhân sẽ hỗ trợ và tư vấn trong suốt quá trình để đảm bảo bạn có thể hoàn thành tác phẩm một cách tốt nhất.
        </p>

        <div class="bg-green-50 border-l-4 border-green-400 p-6 my-8">
          <h3 class="text-lg font-semibold text-green-800 mb-2">Lưu ý quan trọng</h3>
          <p class="text-green-700 mb-2">
            Do quy trình sơn mài truyền thống cần nhiều thời gian để khô và hoàn thiện, tác phẩm của bạn 
            sẽ được hoàn thiện sau workshop và có thể nhận lại sau 1-2 tuần hoặc được gửi về địa chỉ của bạn.
          </p>
        </div>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Thời gian và địa điểm</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          <strong>Địa điểm:</strong> Làng nghề Hạ Thái, xã Duyên Thái, huyện Thường Tín, Hà Nội<br>
          <strong>Thời gian:</strong> Workshop diễn ra trong khoảng 3-4 giờ, phù hợp cho cả cá nhân và nhóm<br>
          <strong>Độ tuổi:</strong> Phù hợp cho mọi lứa tuổi, đặc biệt là các gia đình có trẻ em
        </p>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Lợi ích của Workshop</h2>
        <ul class="list-disc list-inside text-gray-700 mb-6 space-y-2">
          <li><strong>Hiểu biết sâu sắc:</strong> Tìm hiểu về lịch sử, văn hóa và kỹ thuật của nghề sơn mài truyền thống</li>
          <li><strong>Trải nghiệm thực tế:</strong> Tự tay thực hiện các công đoạn chế tác sơn mài</li>
          <li><strong>Kết nối văn hóa:</strong> Giao lưu với các nghệ nhân và hiểu thêm về đời sống làng nghề</li>
          <li><strong>Sản phẩm độc đáo:</strong> Mang về nhà một tác phẩm sơn mài do chính tay bạn tạo ra</li>
          <li><strong>Kỷ niệm đáng nhớ:</strong> Tạo ra những kỷ niệm đẹp và ý nghĩa cùng gia đình, bạn bè</li>
        </ul>

        <h2 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Đăng ký tham gia</h2>
        <p class="text-gray-700 leading-relaxed mb-6">
          Workshop được tổ chức thường xuyên và có thể đặt lịch theo nhóm. Để đăng ký tham gia, bạn có thể 
          liên hệ trực tiếp với làng nghề Hạ Thái hoặc đặt lịch qua các kênh thông tin chính thức.
        </p>

        <p class="text-gray-700 leading-relaxed mb-8">
          Đây là cơ hội tuyệt vời để bạn và gia đình trải nghiệm một phần văn hóa truyền thống Việt Nam, 
          học hỏi những kỹ thuật cổ xưa và tạo ra những tác phẩm nghệ thuật độc đáo mang đậm dấu ấn cá nhân.
        </p>
      `,
      tags: ['Workshop', 'Trải nghiệm', 'Hạ Thái', 'Làng nghề', 'Sơn mài']
    }
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Get the full URL path
    this.route.url.subscribe(urlSegments => {
      if (urlSegments.length > 0) {
        // Get the last segment which is the blog ID
        const blogId = urlSegments[urlSegments.length - 1].path;
        this.loadBlog(blogId);
      } else {
        // Fallback to default blog
        this.loadBlog('son-mai-truyen-thong');
      }
    });
  }

  private loadBlog(blogId: string): void {
    this.currentBlog = this.blogPosts.find(blog => blog.id === blogId) || this.blogPosts[0];
    // Get related blogs (exclude current blog)
    this.relatedBlogs = this.blogPosts.filter(blog => blog.id !== blogId).slice(0, 2);
  }

  navigateToBlog(blogId: string): void {
    this.router.navigate(['/blog', blogId]);
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}