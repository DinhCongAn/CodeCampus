export interface FilterOption {
  id: string;
  name: string;
  count: number;
}