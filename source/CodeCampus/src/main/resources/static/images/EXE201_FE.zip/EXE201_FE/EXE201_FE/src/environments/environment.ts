export const environment = {
  production: false,
  apiUrl: 'http://localhost:8081',
  payos: {
    returnUrl: 'http://localhost:4200/payment-result',
    cancelUrl: 'http://localhost:4200/checkout'
  }
};
