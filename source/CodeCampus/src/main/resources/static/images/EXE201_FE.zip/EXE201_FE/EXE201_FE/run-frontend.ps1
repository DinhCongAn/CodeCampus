Write-Host "Starting Angular Frontend..." -ForegroundColor Green
Write-Host ""

# Change to frontend directory
Set-Location "EXE201_FE\EXE201_FE"

Write-Host "Current directory: $(Get-Location)" -ForegroundColor Yellow
Write-Host ""

Write-Host "Starting Angular development server..." -ForegroundColor Cyan
npm start

Write-Host ""
Write-Host "Frontend stopped. Press any key to exit..." -ForegroundColor Red
Read-Host
