export const RouterConstant = {
    login: "Dang-nhap",
    register: "Dang-ky",
    home: "Trang-chu",
    productCategory: "Danh-muc-san-pham",
    detailProduct: "Danh-muc-san-pham/:id",
    cart: "Gio-hang",
    blogDetail: "blog/son-mai-truyen-thong"
};