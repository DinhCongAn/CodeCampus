export const environment = {
  production: true,
  apiUrl: 'https://your-domain.com/api' // Thay bằng domain thật của bạn
};
